# woo-dashboard
A simple dashboard for woocommerce store

For detailed implementation see my blog: https://www.cloudways.com/blog/custom-dashboard-using-woocommerce-php-rest-api/
